package FirstProject.DemoProject;

/**
 * Hello world!
 *
 */


import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.*;


public class App 
{
    public static void main( String[] args )
    {
    	 SparkSession spark = SparkSession
                 .builder()
                 .appName("Java Spark SQL Example")
                 .config("spark.master", "local")
                 .getOrCreate();
    	 Dataset<Row> df = spark.read()
                 .format("com.crealytics.spark.excel")
                 .option("useHeader", "true")
                .load("C:\\\\Users\\\\S537154\\\\Documents\\\\Book.xlsx");
    	        df.registerTempTable("Student");
    	  spark.sql("SELECT * FROM Student").show(); 
    	 spark.sql("SELECT * FROM Student where status=\"Full Time\"").show();
   	
		
    }
					  
}
